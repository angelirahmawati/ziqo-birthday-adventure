//==============================
// ZIQO BIRTHDAY ADVENTURE V2
// PART 1
//==============================

let gameState = "intro";

let introPages = [
  "Loading Memories...",
  "Ada seseorang yang sedang menunggu di akhir perjalanan.",
  "Kumpulkan semua item dan temukan jalan menuju tujuan terakhir.",
  "Klik untuk memulai."
];

let currentPage = 0;

let cameraX = 0;

let gravity = 0.7;

let player = {
  x: 80,
  y: 100,
  w: 32,
  h: 42,
  vx: 0,
  vy: 0,
  speed: 5,
  jump: -14,
  onGround: false
};

let blocks = [
  {x:0,y:420},
  {x:40,y:420},
  {x:80,y:420},
  {x:120,y:420},
  {x:160,y:420},
  {x:200,y:420},
  {x:240,y:420},
  {x:280,y:420},

  {x:400,y:360},
  {x:440,y:360},
  {x:480,y:360},

  {x:620,y:300},
  {x:660,y:300},
  {x:700,y:300},

  {x:860,y:360},
  {x:900,y:360},
  {x:940,y:360},

  {x:1080,y:260},
  {x:1120,y:260},
  {x:1160,y:260},

  {x:1320,y:420},
  {x:1360,y:420},
  {x:1400,y:420},
  {x:1440,y:420}
];

let coins = [
  {x:420,y:320,taken:false},
  {x:470,y:320,taken:false},
  {x:520,y:320,taken:false},

  {x:640,y:260,taken:false},
  {x:680,y:220,taken:false},
  {x:720,y:180,taken:false},

  {x:900,y:320,taken:false},
  {x:940,y:280,taken:false},

  {x:1100,y:220,taken:false},
  {x:1140,y:180,taken:false},
  {x:1180,y:220,taken:false}
];

let boxes = [
  {x:520,y:250,opened:false},
  {x:660,y:160,opened:false},
  {x:1150,y:190,opened:false}
];

let score = 0;

let enemies = [
  {x:420,y:328,w:30,h:30,dir:1,minX:400,maxX:500,alive:true},

  {x:640,y:268,w:30,h:30,dir:-1,minX:620,maxX:720,alive:true},

  {x:880,y:328,w:30,h:30,dir:1,minX:860,maxX:960,alive:true},

  {x:1100,y:228,w:30,h:30,dir:-1,minX:1080,maxX:1180,alive:true},

  {x:1340,y:388,w:30,h:30,dir:1,minX:1320,maxX:1440,alive:true}
];

let lives = 3;

let checkpointX = 80;
let checkpointY = 100;

let invincible = 0;

let hasStar = false;

let bullets = [];
let fireballs = [];

let letterPage = 0;

let letterPages = [

"Hai, kamu... ❤️\n\nHappy Birthday yaa!! 🎉🎂\n\nTerima kasih ya karena selama ini kamu selalu sabar sama aku, selalu sayang,\n\nselalu peduli, selalu perhatian, dan selalu ada setiap aku butuh.",

"Terima kasih sudah menjadi seseorang yang membuat hari-hariku lebih berwarna.\n\nDi hari spesial kamu ini,\n\naku berdoa semoga kamu selalu diberi kesehatan,\n\npanjang umur, dan dimudahkan semua urusannya.",

"Semoga semua cita-cita, impian, dan keinginan kamu bisa tercapai satu per satu.\n\nAku akan selalu mendukung setiap langkah yang kamu pilih. 🤍",

"Aku juga punya satu permintaan kecil...\n\nIngat selalu aku yaa. ❤️\n\nMaaf kalau selama ini aku sering ngeselin atau bikin kamu kesel.",

"Terima kasih karena kamu masih tetap sabar menghadapi aku sampai sekarang.\n\nAku bersyukur bisa punya banyak kenangan bersama kamu.",

"Aku membuat game kecil ini khusus untuk kamu.\n\nMungkin masih sederhana dan masih banyak kurangnya,\n\ntapi setiap bagiannya aku buat sambil memikirkan kamu.",

"Kalau masih ada yang kurang dari game ini, bilang yaa.\n\nKarena kalau itu buat kamu, aku selalu ingin memberikan yang terbaik.",

"Selamat bertambah usia, Ziqo. 🤍\n\nSemoga Tuhan selalu menjaga setiap langkahmu dan memberikan banyak alasan untuk terus tersenyum.",

"Dan semoga...\n\nkita masih bisa membuat banyak kenangan baru bersama. ❤️\n\nI love you, always.\n\n— Dari seseorang yang selalu sayang sama kamu. 🤍"

];

let boss = {
  x: 1500,
  y: 330,
  w: 90,
  h: 90,
  hp: 8,
  alive: true,
  vy: 0,
  jumpTimer: 0
};

function setup(){
  createCanvas(900,500);
  textAlign(CENTER,CENTER);
  rectMode(CORNER);
}

function draw(){

  if(ending){

  background(20);

  drawBalloons();

  fill(255);

  textAlign(CENTER,CENTER);

  textSize(35);
  text(
    "💌 Surat Terakhir",
    width/2,
    60
  );


  textSize(13);

  let lines = letterPages[letterPage].split("\n");

textSize(18);

for(let i = 0; i < lines.length; i++){

  text(
    lines[i],
    width/2,
    150 + (i * 28)
  );

}


  textSize(16);

  text(
    "Klik untuk membuka halaman berikutnya",
    width/2,
    height-40
  );

  return;

}

  if(gameState=="intro"){

  background(20);

  fill(255);

  textAlign(CENTER,CENTER);

  textSize(18);

  text(
    introPages[currentPage],
    50,
    100,
    width-100,
    height-200
  );

  textSize(18);

  text(
    "Klik untuk lanjut",
    width/2,
    height-40
  );

  return;

}

  if(gameState=="gameover"){
    
    background(20)

    fill(255,0,0);
    textSize(60);
    text("GAME OVER",width/2,height/2-40);

    fill(255);
    textSize(24);
    text("Klik untuk mengulang",width/2,height/2+30);

    return;
    
  }

  background(135,206,235);

  cameraX = constrain(player.x-250,0,999999);

  push();
  translate(-cameraX,0);

  drawBlocks();

  drawCoins();

  drawBoxes();

  drawEnemies();

  drawBoss();

  drawDoor();

  updateBoss();

  drawFireballs();

  updateFireballs();

  drawBullets();

  updatePlayer();

  updateBullets();

  checkCoins();

  checkBoxes();

  updateEnemies();

  checkEnemies();

  checkDoor();

  drawPlayer();

  pop();

  fill(255);
  textAlign(LEFT,TOP);
  textSize(22);
  text("🪙 "+score,20,20);
  text("❤️ "+lives,20,50);

  if(boss.alive){

  textAlign(CENTER);
  textSize(24);

  text(
    "👑 BOSS HP : " + boss.hp,
    width/2,
    30
  );

}

  if(hasStar){
    text("⭐️ MAGIC STAR",20,80);
  }
  
}

function drawBlocks(){

  for(let b of blocks){

    fill(145,95,45);
    rect(b.x,b.y,40,40);

    stroke(100,70,35);
    noFill();
    rect(b.x,b.y,40,40);
    noStroke();

  }

}

function updatePlayer(){

  if(invincible > 0){
    invincible--;
  }

  player.vx = 0;

  if(keyIsDown(LEFT_ARROW) || keyIsDown(65)){
    player.vx = -player.speed;
  }

  if(keyIsDown(RIGHT_ARROW) || keyIsDown(68)){
    player.vx = player.speed;
  }

  player.x += player.vx;

  player.vy += gravity;
  player.y += player.vy;

  player.onGround = false;

  for(let b of blocks){

    if(
      player.x + player.w > b.x &&
      player.x < b.x + 40 &&
      player.y + player.h >= b.y &&
      player.y + player.h <= b.y + 15 &&
      player.vy >= 0
    ){

      player.y = b.y - player.h;
      player.vy = 0;
      player.onGround = true;

      checkpointX = player.x;
      checkpointY = player.y;

    }

  }

  // Jatuh ke jurang
  if(player.y > height + 100){

    lives--;

    if(lives > 0){

      player.x = checkpointX;
      player.y = checkpointY;

      player.vx = 0;
      player.vy = 0;

    }else{

      gameState = "gameover";

    }

  }

}

function drawPlayer(){

  fill(255,220,180);
  rect(player.x+6,player.y,20,18,4);

  fill(40);
  rect(player.x+4,player.y+18,24,18,4);

  fill(60,90,255);
  rect(player.x+7,player.y+36,6,6);
  rect(player.x+19,player.y+36,6,6);

}

function keyPressed(){

  if((key == " " || keyCode == 32) && player.onGround){
    player.vy = player.jump;
  }

  if((key == "f" || key == "F") && hasStar){

    bullets.push({

      x: player.x + player.w,
      y: player.y + player.h / 2,
      vx: 8

    });

  }

}

function mousePressed(){

  if(ending){

  letterPage++;

  if(letterPage >= letterPages.length){
    letterPage = letterPages.length-1;
  }

  return;

}

  if(gameState=="intro"){

    currentPage++;

    if(currentPage >= introPages.length){
      gameState = "game";
    }

    return;
  }

  if(gameState=="gameover"){

    lives = 3;
    score = 0;

    player.x = 80;
    player.y = 100;
    player.vx = 0;
    player.vy = 0;

    checkpointX = 80;
    checkpointY = 100;

    for(let c of coins){
      c.taken = false;
    }

    for(let b of boxes){
      b.opened = false;
    }

    for(let e of enemies){
      e.alive = true;
    }

    gameState = "game";

  }

}

function drawCoins(){

  for(let c of coins){

    if(c.taken) continue;

    fill(255,220,0);
    circle(c.x,c.y,18);

  }

}

function checkCoins(){

  for(let c of coins){

    if(c.taken) continue;

    if(
      dist(
        player.x+player.w/2,
        player.y+player.h/2,
        c.x,
        c.y
      )<25
    ){
      c.taken=true;
      score++;
    }

  }

}

function drawBoxes(){

  textAlign(CENTER,CENTER);

  for(let b of boxes){

    if(b.opened){

      fill(150);
      rect(b.x,b.y,40,40);

    }else{

      fill(240,170,30);
      rect(b.x,b.y,40,40);

      fill(255);
      textSize(24);
      text("?",b.x+20,b.y+20);

    }

  }

}

function checkBoxes(){

  for(let b of boxes){

    if(b.opened) continue;

    if(
      player.vy < 0 &&
      player.x + player.w > b.x &&
      player.x < b.x + 40 &&
      player.y < b.y + 40 &&
      player.y > b.y
    ){

      b.opened = true;

      if(b.x == 660){
        hasStar = true;
      }else{
        score++;
      }

    }

  }

}

function drawEnemies(){

  for(let e of enemies){

    if(!e.alive) continue;

    fill(180,70,70);
    rect(e.x,e.y,e.w,e.h,6);

    fill(255);
    circle(e.x+10,e.y+10,5);
    circle(e.x+20,e.y+10,5);

  }

}

function updateEnemies(){

  for(let e of enemies){

    if(!e.alive) continue;

    e.x += e.dir * 1.5;

    if(e.x < e.minX){
      e.dir = 1;
    }

    if(e.x > e.maxX){
      e.dir = -1;
    }

  }

}

function checkEnemies(){

  for(let e of enemies){

    if(!e.alive) continue;

    if(
      invincible == 0 &&
      player.x + player.w > e.x &&
      player.x < e.x + e.w &&
      player.y + player.h > e.y &&
      player.y < e.y + e.h
    ){

      // Injak dari atas
      if(player.vy > 0 && player.y + player.h < e.y + 15){

        e.alive = false;
        player.vy = -10;

      }else{

        lives--;
        invincible = 60;

        if(lives > 0){

          player.x = checkpointX;
          player.y = checkpointY;
          player.vx = 0;
          player.vy = 0;

        }else{

          gameState = "gameover";
          
        }
        
      }

    }

  }

}

function drawBullets(){

  for(let b of bullets){

    fill(255,255,0);
    circle(b.x,b.y,12);

  }

}

function updateBullets(){

  for(let i = bullets.length - 1; i >= 0; i--){

    bullets[i].x += bullets[i].vx;


    // kena musuh biasa
    for(let e of enemies){

      if(!e.alive) continue;

      if(
        bullets[i].x > e.x &&
        bullets[i].x < e.x + e.w &&
        bullets[i].y > e.y &&
        bullets[i].y < e.y + e.h
      ){

        e.alive = false;

        bullets.splice(i,1);
        break;

      }

    }


    // kena boss
    if(
      boss.alive &&
      i < bullets.length &&
      bullets[i].x > boss.x &&
      bullets[i].x < boss.x + boss.w &&
      bullets[i].y > boss.y &&
      bullets[i].y < boss.y + boss.h
    ){

      boss.hp--;

      bullets.splice(i,1);


      if(boss.hp <= 0){

        boss.alive = false;

      }

      continue;

    }


    // hapus peluru jauh

    if(i < bullets.length){

      if(
        bullets[i].x < cameraX - 100 ||
        bullets[i].x > cameraX + width + 100
      ){

        bullets.splice(i,1);

      }

    }

  }

}

function drawBoss(){

  if(!boss.alive) return;

  fill(120,40,40);
  rect(boss.x,boss.y,boss.w,boss.h,10);

  fill(255);
  circle(boss.x+25,boss.y+25,12);
  circle(boss.x+65,boss.y+25,12);

  fill(0);
  circle(boss.x+25,boss.y+25,5);
  circle(boss.x+65,boss.y+25,5);

  fill(0);
  rect(boss.x+25,boss.y+60,40,8,5);

}


function updateBoss(){

  if(!boss.alive) return;

  boss.jumpTimer++;

  boss.vy += gravity;
  boss.y += boss.vy;


  if(boss.y >= 330){

    boss.y = 330;
    boss.vy = 0;

  }


  if(boss.jumpTimer > 120){

    boss.vy = -12;

    fireballs.push({

      x: boss.x,
      y: boss.y + 40,
      vx: -6

    });

    boss.jumpTimer = 0;

  }

}

function drawFireballs(){

  for(let f of fireballs){

    fill(255,80,0);
    circle(f.x,f.y,18);

  }

}


function updateFireballs(){

  for(let i = fireballs.length-1; i >= 0; i--){

    fireballs[i].x += fireballs[i].vx;


    if(fireballs[i].x < 0){

      fireballs.splice(i,1);

    }

  }

}

let door = {
  x: 1500,
  y: 350,
  w: 50,
  h: 90
};

let ending = false;

let balloons = [
  {x:100,y:500},
  {x:250,y:550},
  {x:450,y:520},
  {x:650,y:560},
  {x:800,y:530}
];


function drawDoor(){

  if(boss.alive) return;

  fill(120,70,20);
  rect(door.x,door.y,door.w,door.h);

  fill(255,220,0);
  circle(
    door.x+35,
    door.y+45,
    8
  );

}


function checkDoor(){

  if(boss.alive) return;

  if(
    player.x + player.w > door.x &&
    player.x < door.x + door.w &&
    player.y + player.h > door.y
  ){

    ending = true;

  }

}

function drawBalloons(){

  for(let b of balloons){

    fill(255,100,150);
    circle(b.x,b.y,40);

    stroke(0);
    line(b.x,b.y+20,b.x,b.y+80);
    noStroke();

    b.y -= 0.5;

    if(b.y < -50){
      b.y = height+50;
    }

  }

}